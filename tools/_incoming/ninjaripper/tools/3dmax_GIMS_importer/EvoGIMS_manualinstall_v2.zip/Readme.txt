Hi , I had lot of requests about GIMS for 3ds max 2016+ , Well here we go I fixed it.
Tested on 3dsmax 2018 and 2020 and it works fine.
https://gtaforums.com/topic/929447-gta-v-gims-for-3dsmax-2017-2020/


Install:
	1. Copy 'scripts' folder to 3ds max root. Example: 'C:\Program Files\Autodesk\3ds Max 2017\'
	2. Copy 'GIMS' folder to 'C:\Users\<yourusername>\AppData\Local\'


Changes with v2 (by Stochastic Hegemony):

Fixes :
	- "Shared Core" Error on startup
	- "Utilities Missed" Error on startup
	- "Can't find resources" Error on Importing
	- NinjaRipper and Max Payne 3 Fixed too.
	- .Net GUI Issues on start up
	- "Run-Time" error on Exporting
	- "Run-Time" error on material converting

Note that the export command will still take a long time if you use a very complex scene. This version has function time tracking commented out.

Enjoy :)